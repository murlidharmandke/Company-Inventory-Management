<script setup lang="ts">
import { ref, reactive } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()
const step = ref(3)

const steps = reactive([
  {
    value: 1,
    title: 'Company Details',
    icon: 'mdi-office-building',
    content: 'Start your job search here.',
    status: true,
  },
  {
    value: 2,
    title: 'Add User',
    icon: 'mdi-account-plus',
    content: 'Fill in all required application details.',
    status: false,
  },
  {
    value: 3,
    title: 'Submit for Approval',
    icon: 'mdi-send',
    content: 'Prepare for your interview.',
    status: false,
  },
])

const setStepStatus = (index: number, value: boolean) => {
  console.log('Setting step status:', index, value);
  
  steps[index].status = value
}

const handleStepClick = (step: { href?: string }) => {
  if (step.href) {
    router.push(step.href)
  }
}
</script>
<template>
  <div>
    <layout>
      <template #default>
        <div class="d-flex flex-column align-center justify-center pa-10 text-secondary ">
          <span>Setup your company inventory management/ buying system in 3 steps</span>
        </div>
        <Stepper :step-items="steps" />
        <CompanyDetails v-if="steps[0].status && !steps[1].status && !steps[2].status" class="ma-10" @submit="setStepStatus" />
        <AddUser v-if="steps[1].status && !steps[2].status" class="ma-10" />
        <SubmitForApproval v-if="steps[2].status" class="ma-10" />
      </template>
    </layout>
  </div>
</template>

<style lang="scss">
.custom-stepper-header {
  .v-stepper-header {
    box-shadow: none !important;
  }
}

.v-stepper--alt-labels .v-stepper-item__avatar.v-avatar {
  height: 43px !important;
  width: 43px !important;

}
</style>
