import { defineStore } from 'pinia'


export const useCompanyDetailsStore = defineStore('companyDetails', {
  state: () => ({
    companyName: '',
    websiteUrl: '',
    yourName: '',
    email: '',
    mobileNo: '',
    billingAddress: '',
    pan: '',
    tan: '',
    cin: '',
    gst: '',
    selectedRoles:Boolean,
    name:'',
    description:'',
    mobile:'',
    userEmail:'',
  
  }),
  getters: {
    getCompanyDetails: (state) => state,
    isFormComplete: (state) =>
      !!state.companyName &&
      !!state.yourName &&
      !!state.email &&
      !!state.mobileNo &&
      !!state.billingAddress &&
      !!state.pan &&
      !!state.cin &&
      !!state.name &&
      !! state.description &&
      !! state.mobile &&
      !! state.userEmail&&
      !! state.selectedRoles,
  },
  actions: {
    setCompanyDetails(details: Partial<ReturnType<typeof this.$state>>) {
      Object.assign(this.$state, details)
    },
    resetForm() {
      this.companyName = ''
      this.websiteUrl = ''
      this.yourName = ''
      this.email = ''
      this.mobileNo = ''
      this.billingAddress = ''
      this.pan = ''
      this.tan = ''
      this.cin = ''
      this.gst = ''
      this.name = ''
      this.description = ''
      this.mobile = ''
      this.userEmail = ''
      this.selectedRoles = false  

    },
  },
})