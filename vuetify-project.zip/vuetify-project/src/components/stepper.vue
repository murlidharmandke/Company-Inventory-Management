<script lang="ts" setup>
import { useRouter } from "vue-router";
import { ref } from "vue";
const step = ref(1);

export interface StepItem {
  title: string;
  status: boolean;
  value: number;
  href?: string;
  icon?: string;
}

export interface Props {
  stepItems: StepItem[];
  elevation?: number;
  border?: boolean;
  altLabels?: boolean;
  hideActions?: boolean;
  mobile?: boolean;
  rounded?: string | number | boolean;
  bgColor?: string;
  editable?: boolean;
  nonLinear?: boolean;
}
const props = withDefaults(defineProps<Props>(), {
  stepItems: () => [
    { title: "Quote", status: true, value: 1 },
    { title: "AWB Execution", status: false, value: 2 },
    { title: "Integrated Clearance", status: false, value: 3 },
  ],
  elevation: 0,
  border: false,
  altLabels: false,
  hideActions: true,
  mobile: false,
  rounded: "lg",
  bgColor: "white",
  editable: true,
  nonLinear: true,
});

const stepItems = props.stepItems;

const router = useRouter();

const updateLastStepStatus = () => {
  const lastIndex = stepItems.length - 1;
  const anyCompleted = stepItems.some((item, idx) => item.status && idx !== lastIndex);
  if (anyCompleted) {
    stepItems[lastIndex].status = true;
  }
};
</script>
<template>
  <v-stepper v-model="step" class="mx-auto" flat alt-labels width="30%" elevation="0">
    <v-stepper-header>
      <template v-for="(item, idx) in stepItems" :key="item.value">
        <v-stepper-item
          :value="item.value"
          :complete="item.status"
          :title="item.title"
          :step="idx + 1"
          size="70px"
          class="rounded-xl"
          :class="{
            'completed-step': item.status === true,
            'incomplete-step': item.status === false,
          }"
          @click="step = item.value"
        >
          <template #icon="{ props }">
            <v-icon size="26px" v-bind="props" :icon="item.icon" class=""></v-icon>
          </template>
        </v-stepper-item>
        <v-divider
          v-if="idx < stepItems.length - 1"
          thickness="6px"
          length="20%"
          class="rounded-xl"
          :class="{ 'completed-step-divider': item.status === true }"
        ></v-divider>
      </template>
    </v-stepper-header>
  </v-stepper>
</template>

<style lang="scss">
.completed-step {
  .v-stepper-item__avatar.v-avatar {
    background-color: #48a9a6 !important;
    opacity: 30 !important;
  }
}

.completed-step-divider {
  .v-divider:has(~ .v-stepper-item--selected) {
    color: #48a9a6 !important;
    opacity: 30 !important;
  }
}
</style>
