<script setup lang="ts">
import { ref } from 'vue'
import { useCompanyDetailsStore } from '@/store/store' // adjust path if needed
import { useForm, useField } from 'vee-validate'
import * as yup from 'yup';

const emit = defineEmits(['submit'])

const schema = yup.object({
  email: yup.string().email().required(),
  companyName: yup.string().required(),
  yourName: yup.string().required(),
  mobileNo: yup
    .string()
    .required('Mobile number is required')
    .matches(/^[6-9]\d{9}$/, 'Enter a valid 10-digit mobile number'),
  billingAddress: yup.string().required(),
  pan: yup.string().required(),
  tan: yup.string(),
  cin: yup.string().required(),
  gst: yup.string().required(),

});


const { handleSubmit } = useForm({ validationSchema: schema })
const companyName = useField('companyName')
const websiteUrl = ref('')
const yourName = useField('yourName')
const email = useField('email')
const mobileNo = useField('mobileNo')
const billingAddress = useField('billingAddress')
const pan = useField('pan')
const tan = ref('')
const cin = useField('cin')
const gst = useField('gst')

const companyStore = useCompanyDetailsStore()

const saveCompanyDetails = handleSubmit((values) => {

  emit('submit', 1, true)

  companyStore.setCompanyDetails({
    companyName: values.companyName,
    websiteUrl: values.websiteUrl,
    yourName: values.yourName,
    email: values.email,
    mobileNo: values.mobileNo,
    billingAddress: values.billingAddress,
    pan: values.pan,
    tan: values.tan,
    cin: values.cin,
    gst: values.gst
  })
  console.log('Company Details:', companyStore.getCompanyDetails)
  // Add your logic to save the company details here
})
</script>

<template>
  <div class="d-flex align-center justify-center">
    <v-sheet elevation="3" rounded class="d-flex flex-column" width="80%" hight="auto">
      <div class="d-flex align-center justify-start border-b">
        <div class="px-3">
          <v-icon icon="mdi-office-building" size="50px" color="secondary"></v-icon>
        </div>
        <div class="d-flex flex-column pa-5">
          <span class="text-secondary text-h6">Company Details</span>
          <span>
            Adding your company's details is a mandatory step in registering your company.
          </span>
        </div>
      </div>
      <div>
        <v-form @submit.prevent="saveCompanyDetails">
          <v-row class="" dense>
            <v-col cols="12" md="6">
              <v-col cols="12">
                <v-row class="d-flex align-center">
                  <v-col class="d-flex align-center justify-end">
                    <span class="">Register Company Name </span>
                    <span class="mandatory-icon">*</span>
                  </v-col>
                  <v-col>
                    <v-text-field label="Company Name" variant="outlined" class="pt-5" width="312px"
                      :error-messages="companyName.errorMessage.value"
                      hint="Company Name as Registered on official documents" v-model="companyName.value.value"
                      ></v-text-field>
                  </v-col>
                </v-row>
              </v-col>
              <v-col cols="12">
                <v-row class="d-flex align-center justify-start ">
                  <v-col class="d-flex align-center justify-end">
                    <span>Website URL</span>
                  </v-col>
                  <v-col>
                    <v-text-field label="For E.g www.PNG.com" variant="outlined" class="pt-5" width="312px"
                      v-model="websiteUrl"></v-text-field>
                  </v-col>
                </v-row>
              </v-col>
              <v-col cols="12">
                <v-row class="d-flex align-center justify-start ">
                  <v-col class="d-flex align-center justify-end">
                    <span>Your Name</span>
                    <span class="mandatory-icon">*</span>
                  </v-col>
                  <v-col>
                    <v-text-field label="Your Name" variant="outlined" class="pt-5" width="312px"
                    :error-messages="yourName.errorMessage.value" v-model="yourName.value.value"></v-text-field></v-col>
                </v-row>
              </v-col>
              <v-col cols="12">
                <v-row class="d-flex align-center justify-start">
                  <v-col class="d-flex align-center justify-end">
                    <span class="">Your Email ID </span>
                    <span class="mandatory-icon">*</span>
                  </v-col>
                  <v-col>
                    <v-text-field
                      label="Enter Your Email ID"
                      variant="outlined"
                      class="pt-5"
                      width="312px"
                      :error-messages="email.errorMessage.value"
                      hint="The above email will be treated as company's admin ID and will be used for registration process"
                      v-model="email.value.value"
                    />
                  </v-col>
                </v-row>
              </v-col>
              <v-col cols="12">
                <v-row class="d-flex align-center justify-start">
                  <v-col class="d-flex align-center justify-end">
                    <span>Your Mobile No</span>
                    <span class="mandatory-icon">*</span>
                  </v-col>
                    <v-col>
                    <v-text-field
                      label="Enter Your Mobile No"
                      variant="outlined"
                      class="pt-5"
                      width="312px"
                     
                      hint="The above mobile treated as company's admin no and will be used  for registration  process"
                      v-model="mobileNo.value.value"
                      :error-messages="mobileNo.errorMessage.value"
                    ></v-text-field>
                    </v-col>
                  </v-row>
              </v-col>
              <v-col cols="12">
                <v-row class="d-flex align-start justify-start">
                  <v-col class="d-flex align-start justify-end pt-7">
                    <span class="">Billing Address </span>
                    <span class="mandatory-icon">*</span>
                  </v-col>
                  <v-col>
                    <v-textarea
                      label="Enter Your Company Billing Address"
                      variant="outlined"
                      class="pt-5"
                      width="312px"
                      hint="Will be used for all offline communications and billing purposes"
                     
                      v-model="billingAddress.value.value"
                      :error-messages="billingAddress.errorMessage.value"
                    />
                  </v-col>
                </v-row>
              </v-col>

            </v-col>
            <v-col cols="12" md="6">
              <v-col>
                <v-row class="d-flex align-center justify-start">
                  <v-col class="d-flex justify-end align-center"> <span class="">PAN No. </span>
                    <span class="mandatory-icon">*</span></v-col>
                  <v-col>
                    <v-text-field
                      label="Enter Company PAN No."
                      variant="outlined"
                      class="pt-5"
                      hint="Company Name as Registered on official documents"
                      v-model="pan.value.value"
                      :error-messages="pan.errorMessage.value"
                    
                    />
                  </v-col>
                  <v-col class="d-flex justify-center align-center"> <v-btn hide-details :variant="'outlined'"
                      color="secondary" class="rounded-xl text-capitalize px-5 mx-2"
                      label="Upload">Upload</v-btn></v-col>
                </v-row>
              </v-col>
              <v-col>
                <v-row class="d-flex align-center justify-start">
                  <v-col class="d-flex justify-end align-center"> <span class="">TAN No. </span>
                  </v-col>
                  <v-col>
                    <v-text-field label="Enter Company TAN No." variant="outlined" class="pt-5"
                      hint="Company Name as Registered on official documents" v-model="tan"></v-text-field>
                  </v-col>
                  <v-col class="d-flex justify-center align-center"> <v-btn hide-details :variant="'outlined'"
                      color="secondary" class="rounded-xl text-capitalize px-5 mx-2"
                      label="Upload">Upload</v-btn></v-col>
                </v-row>
              </v-col>
              <v-col>
                <v-row class="d-flex align-center justify-start">
                  <v-col class="d-flex justify-end align-center"> <span class="">CIN No. </span>
                    <span class="mandatory-icon">*</span></v-col>
                  <v-col>
                    <v-text-field
                      label="Enter Company CIN No."
                      variant="outlined"
                      class="pt-5"
                      hint="Company Name as Registered on official documents"
                      v-model="cin.value.value" 
                      :error-messages="cin.errorMessage.value"
                 
                    />
                  </v-col>
                  <v-col class="d-flex justify-center align-center"> <v-btn hide-details :variant="'outlined'"
                      color="secondary" class="rounded-xl text-capitalize px-5 mx-2"
                      label="Upload">Upload</v-btn></v-col>
                </v-row>
              </v-col>
              <v-col>
                <v-row class="d-flex align-center justify-start">
                  <v-col class="d-flex justify-end align-center"> <span class="">GST No. </span></v-col>
                    <v-col>
                    <v-text-field
                      label="Enter Company GST No."
                      variant="outlined"
                      class="pt-5"
                      hint="Company Name as Registered on official documents"
                      v-model="gst.value.value"
                      :error-messages="gst.errorMessage.value"
                    />
                    </v-col>
                  <v-col class="d-flex justify-center align-center"> <v-btn hide-details :variant="'outlined'"
                      color="secondary" class="rounded-xl text-capitalize px-5 mx-2"
                      label="Upload">Upload</v-btn></v-col>
                </v-row>
              </v-col>

              <v-col>
                <v-row class="d-flex align-center justify-start">
                  <v-col class="d-flex align-center justify-end">
                    <div class="d-flex flex-column">
                      <span class="mt-3 d-flex align-center justify-end">Cancelled Cheque.</span>
                      <span class="text-subtitle-2 text-grey">(only PDF file format is allowed)</span>
                    </div>
                    <span class="mandatory-icon">*</span>
                  </v-col>
                  <v-col><v-btn hide-details :variant="'outlined'" color="secondary"
                      class="rounded-xl text-capitalize px-5 mx-2" label="Upload">Upload</v-btn></v-col>
                  <v-col></v-col>

                </v-row>
              </v-col>
              <v-col>
                <v-row class="d-flex align-center justify-start">
                  <v-col class="d-flex align-center justify-end">
                    <div class="d-flex flex-column justify-end">
                      <span class="mt-3 d-flex align-center justify-end">Company Registration Certificate</span>
                      <span class="text-subtitle-2 text-grey d-flex justify-end">(only PDF file format is
                        allowed)</span>
                    </div>
                    <span class="mandatory-icon">*</span>
                  </v-col>
                  <v-col><v-btn hide-details :variant="'outlined'" color="secondary"
                      class="rounded-xl text-capitalize px-5 mx-2" label="Upload">Upload</v-btn></v-col>
                  <v-col></v-col>

                </v-row>
              </v-col>
              <v-col>
                <v-row class="d-flex align-center justify-start">
                  <v-col class="d-flex align-center justify-end">
                    <div class="d-flex flex-column">
                      <span class="mt-3 d-flex align-center justify-end">Management Authorization </span>
                      <span class="text-subtitle-2 text-grey">(only PDF file format is allowed)</span>
                    </div>
                    <span class="mandatory-icon">*</span>
                  </v-col>
                  <v-col><v-btn hide-details :variant="'outlined'" color="secondary"
                      class="rounded-xl text-capitalize px-5 mx-2" label="Upload">Upload</v-btn></v-col>
                  <v-col></v-col>

                </v-row>
              </v-col>


            </v-col>



          </v-row>
        </v-form>
      </div>

      <div class="d-flex flex-column  pa-14 ga-4">
        <v-row class="d-flex align-center justify-center">
          <v-col class="d-flex justify-center align-center">
            <v-btn hide-details :variant="'outlined'" color="secondary" class="rounded text-capitalize px-7 mx-2"
              label="Save">Back</v-btn>
            <v-btn hide-details color="secondary" class="rounded text-capitalize px-5 mx-2 " type="submit"
              appendIcon="mdi-chevron-right" label="Next" @click="saveCompanyDetails">Next</v-btn>
          </v-col>
        </v-row>

        <div class="d-flex align-center justify-center">
          <span> Clicked the entered information before proceeding in tha next part of the form</span>
        </div>

      </div>
    </v-sheet>
  </div>
</template>
<style lang="scss">
.mandatory-icon {
  color: red;
  font-size: 1rem;
  margin-left: 4px;
  vertical-align: middle;
}
</style>
