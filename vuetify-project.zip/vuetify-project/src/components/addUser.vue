<script setup lang="ts">
import { ref } from 'vue'
import { useDisplay } from "vuetify";

const { smAndDown } = useDisplay();
const openAddUserModal = ref(false)

const toggleAddUserModal = () => {
    openAddUserModal.value = !openAddUserModal.value
}


</script>

<template>
    <div class="d-flex align-center justify-center">
        <v-sheet elevation="3" rounded class="d-flex flex-column" :width="smAndDown?'100%':'80%'" hight="auto">
            <div class="d-flex align-center justify-start border-b">
                <div class="px-3">
                    <v-icon icon="mdi-account-plus" size="50px" color="secondary"></v-icon>
                </div>
                <div class="d-flex flex-column pa-5">
                    <span class="text-secondary text-h6">Add Users</span>
                    <span>
                        Adding your company's details is a mandatory step in registering your company.
                    </span>
                </div>
            </div>
            <div class="d-flex justify-center flex-column py-16 align-center ">
                <v-icon :icon="'mdi-account-group'" size="108px" color="secondary"></v-icon>
                <span class="text-h6">No User Added yet</span>
                <span class="text-grey">Start by Adding your first User</span>
                <v-btn class="ma-5" prepend-icon="mdi-plus" color="secondary" :variant="'outlined'"
                    @click="toggleAddUserModal"> Add new User</v-btn>
            </div>

        </v-sheet>
        <add-user-modal v-model="openAddUserModal" @close="openAddUserModal = false" />

    </div>
</template>
<style lang="scss">
.mandatory-icon {
    color: red;
    font-size: 1rem;
    margin-left: 4px;
    vertical-align: middle;
}
</style>
