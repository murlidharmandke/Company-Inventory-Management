import { mount } from "@vue/test-utils";
import { describe, expect, test } from "vitest";
import Counter from "../components/Counter.vue"

test('increment the counter', async () => {

    const wrapper = mount(Counter);
    const button = wrapper.find('button');
    await button.trigger('click');
    expect(wrapper.text())
})