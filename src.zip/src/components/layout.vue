<script lang="ts" setup>
const links = [
  'About',
  'Privacy Policy',
  'Terms of Use',
  'Contact Us',
]
const icons = [
  'mdi-linkedin',
  'mdi-facebook',
  'mdi-youtube'
]
</script>
<template>
  <div>

    <v-local-provider>
      <v-app>
        <v-app-bar app>

          <v-spacer></v-spacer>
          <v-btn :variant="'outlined'" class="rounded-xl text-capitalize px-6" :color="'secondary'" :size="'large'">
            Login
          </v-btn>
        </v-app-bar>

        <v-main>
          <slot />
        </v-main>
        <v-footer class="text-center bg-secondary pa-2 justify-space-between " app>

          <div>
            <v-btn class=" text-capitalize" v-for="link in links" :key="link" :text="link" variant="text"
              rounded></v-btn>
          </div>
          <div class="d-flex ga-3 px-6">
            <v-btn v-for="icon in icons" :key="icon" :icon="icon" density="comfortable" variant="text"></v-btn>
          </div>
        </v-footer>
      </v-app>
    </v-local-provider>
  </div>
</template>
