<script setup lang="ts">
import { defineEmits, ref } from "vue";
import { useDisplay } from "vuetify";
import { useCompanyDetailsStore } from '@/store/store' // adjust path if needed
import { useForm, useField } from "vee-validate";
import * as yup from "yup";



const schema = yup.object({
  name: yup.string().required(),
  description: yup.string().required(),
  mobile: yup.string().required('mobile is required').matches(/^[6-9]\d{9}$/, 'Enter a valid 10-digit mobile number'),
  userEmail: yup.string().email().required(),
  selectedRoles: yup.boolean().required()
});
const { handleSubmit } = useForm({ validationSchema: schema })

const { smAndDown } = useDisplay();
const emit = defineEmits(["close"]);
const close = () => {
  // Logic to close the dialog
  console.log("Dialog closed");
  emit("close");
};

// Add this line to define selectedRoles as a reactive array
const selectedRoles = useField('selectedRoles')
const name = useField('name');
const description = useField('description')
const mobile = useField('mobile')
const userEmail = useField('userEmail')



// Dummy roles array for demonstration (replace or move as needed)
const roles = [
  { label: "Seller", value: "seller" },
  { label: "Buyer", value: "buyer" },
  { label: "Billing", value: "billing" },
  { label: "Viewer", value: "view" },
];

const companyStore = useCompanyDetailsStore()

const saveUser = handleSubmit((values) => {
  companyStore.setCompanyDetails({
    name: values.name,
    selectedRoles: values.selectedRoles,
    description: values.description,
    mobile: values.mobile,
    userEmail: values.userEmail
  })
})
</script>
<template>
  <v-dialog :width="smAndDown ? ' 100%' : '65%'" scrim="true">
    <v-sheet class="pa-0" elevation="0">
      <div class="d-flex align-center justify-space-between border-b pa-6">
        <span class="text-secondary custom-text-title">Add User</span>
        <span class="text-grey">(following user data will be reflected on the screen once filled.)</span>
      </div>
      <div>
        <v-form @submit.prevent="saveUser">
          <div class="grid px-16 py-7">
            <div class="grid_field ga-5">
              <div class="d-flex align-center justify-center pl-8">
                <span class="pb-4">Name</span>
                <span class="mandatory-icon d-flex align-start pb-5"> *</span>
              </div>
              <div>
                <v-text-field :variant="'outlined'" label="Enter Name" v-model="name.value.value"
                  :error-messages="name.errorMessage.value"></v-text-field>
              </div>
            </div>
            <div class="grid_field">
              <div class="d-flex align-center justify-center">
                <span class="pb-4">Mobile No.</span>
                <span class="mandatory-icon d-flex align-start pb-5"> *</span>
              </div>
              <div>
                <v-text-field :variant="'outlined'" label="Enter Name" v-model="mobile.value.value"
                  :error-messages="mobile.errorMessage.value"></v-text-field>
              </div>
            </div>
            <div class="grid_field">
              <div class="d-flex align-center justify-center">
                <span class="pb-4">Description.</span>
                <span class="mandatory-icon d-flex align-start pb-5"> *</span>
              </div>
              <div>
                <v-text-field :variant="'outlined'" label="Enter Name" v-model="description.value.value"
                  :error-messages="description.errorMessage.value"></v-text-field>
              </div>
            </div>

            <div class="grid_field">
              <div class="d-flex align-center justify-center px-2">
                <span class="pb-4">Email ID .</span>
                <span class="mandatory-icon d-flex align-start pb-5"> *</span>
              </div>
              <div>
                <v-text-field :variant="'outlined'" label="Enter Name" v-model="userEmail.value.value"
                  :error-messages="userEmail.errorMessage.value"></v-text-field>
              </div>
            </div>
          </div>

          <div class="d-flex ga-5">
            <div class="d-flex align-center justify-end" :class="smAndDown ? '' : 'px-4'">
              <span class="d-flex flex-column">
                <span class="pb-4 d-flex" :class="smAndDown ? 'justify-start' : 'justify-end'">Profile</span>
                <span class="d-flex">(this is note and you need to check)</span>
              </span>
              <span class="mandatory-icon d-flex align-start pb-10">*</span>
            </div>
            <div class="d-flex justify-start ga-5" :class="smAndDown ? 'flex-column' : 'flex-row'">
              <div v-for="role in roles" :key="role.value" class="d-flex justify-start align-center">
                <v-checkbox :label="role.label"  append-icon="" v-model="selectedRoles.value.value"
                  :error-messages="selectedRoles.errorMessage.value" :value="role.value"></v-checkbox>
                <v-icon class="" :icon="'mdi-information-outline'" color="grey"></v-icon>
              </div>
            </div>
          </div>

          <div class="d-flex flex-column align-center justify-center pa-6">
            <div>
              <v-btn class="ma-5 px-5" color="secondary" :variant="'outlined'" type="submit" @click="saveUser">
                Save User</v-btn>
            </div>
            <span>You can view the user's details after saving the changes</span>
          </div>
        </v-form>
      </div>
    </v-sheet>
  </v-dialog>
</template>

<style scoped>
.custom-text-title {
  font-size: 1.5rem;
}

.grid_field {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 20px;
}

.grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 20px;
}

@media screen and (max-width: 768px) {
  .grid {
    display: grid;
    grid-template-columns: repeat(1, 1fr);
    gap: 20px;
  }
}
</style>
